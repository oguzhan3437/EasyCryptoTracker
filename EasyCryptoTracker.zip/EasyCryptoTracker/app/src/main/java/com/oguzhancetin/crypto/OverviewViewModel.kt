package com.oguzhancetin.crypto

import android.arch.lifecycle.ViewModel


class OverviewViewModel : ViewModel() {

    init {

    }

}