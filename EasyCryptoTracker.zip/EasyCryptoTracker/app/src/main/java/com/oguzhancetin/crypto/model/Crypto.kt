package com.oguzhancetin.crypto.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


data class Crypto(
    @Expose
    @SerializedName("id")
    val id: String,
    @Expose
    @SerializedName("currency")
    val currency: String,
    @Expose
    @SerializedName("symbol")
    val symbol: String,
    @Expose
    @SerializedName("name")
    val name: String,
    @Expose
    @SerializedName("logo_url")
    val logoUrl: String,
    @Expose
    @SerializedName("price")
    val price: String,
    @Expose
    @SerializedName("price_date")
    val priceDate: String,
    @Expose
    @SerializedName("price_timestamp")
    val priceTimestamp: String,
    @Expose
    @SerializedName("circulating_supply")
    val circulatingSupply: String,
    @Expose
    @SerializedName("max_supply")
    val maxSupply: String,
    @Expose
    @SerializedName("market_cap")
    val marketCap: String,
    @Expose
    @SerializedName("rank")
    val rank: String,
    @Expose
    @SerializedName("high")
    val high: String,
    @Expose
    @SerializedName("high_timestamp")
    val highTimestamp: String,

)


