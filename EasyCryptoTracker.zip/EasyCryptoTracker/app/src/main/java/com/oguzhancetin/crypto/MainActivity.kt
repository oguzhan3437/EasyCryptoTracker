package com.oguzhancetin.crypto

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.oguzhancetin.crypto.network.CryptoAPIService
import kotlinx.coroutines.*


class MainActivity : AppCompatActivity() {

    var job: Job? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        populateData()

    }

    fun populateData(){
        val api = CryptoAPIService.getRetrofit()

        job = CoroutineScope(Dispatchers.IO).launch {
            val data = api.getAllCurrencies()
            withContext(Dispatchers.Main){
                if(data.isSuccessful){
                    data.body()?.forEach {
                        Log.e("name",it.currency)
                    }
                }
            }
        }
    }
}